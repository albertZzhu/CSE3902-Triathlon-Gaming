﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint4
{
	public class Side
	{
		public enum side
		{
			left,
			right,
			up,
			down,
		};
	}
}
