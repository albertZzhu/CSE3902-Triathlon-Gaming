﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint4
{
	public abstract class GameControlCom
	{
		public abstract void Execute();
	}
}
