﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint4
{
	interface IGameControlCom
	{
		void Execute();
	}
}
