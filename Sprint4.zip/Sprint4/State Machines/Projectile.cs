﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint4.State_Machines
{
    public enum Projectiles
    {
        FIREBALL = 0, BOOMERANG = 1, SPEAR = 2
    }
}
