﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint4.Collision
{
	class NPC2BlockHandler : ICollisionHandler<INPC, IBlock>
	{
		public NPC2BlockHandler()
		{

		}

		public void Handle(INPC enemy, IBlock block, Side.side side)
		{

		}
	}
}